﻿using System.Collections.Generic;
using System.Drawing;
using ImageAmbiance.Processing.ColorsEntity;

namespace ImageAmbiance.Processing
{
    public class ColorDistributionResult
    {
        public Dictionary<Colors, int> Distribution { get; set; }

        public Bitmap Image { get; set; }
    }
}