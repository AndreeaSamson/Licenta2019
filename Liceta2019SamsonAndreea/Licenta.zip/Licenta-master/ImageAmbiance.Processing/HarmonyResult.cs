﻿using System.Collections.Generic;
using System.Drawing;

namespace ImageAmbiance.Processing
{
    public class HarmonyResult
    {
        public string ImageAsBase64 { get;  set; }

        public bool Value { get; set; }

        public IEnumerable<string> ColorsList { get; set; }

        public float HarmonyScore { get; set; }   

    }
}