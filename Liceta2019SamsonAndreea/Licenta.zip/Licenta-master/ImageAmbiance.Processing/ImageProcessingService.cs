﻿using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using ImageAmbiance.Processing.ColorsEntity;

namespace ImageAmbiance.Processing
{
    public class ImageProcessingService
    {
        public IEnumerable<string> GetMostUsedColors(ColorDistributionResult colorDistribution, int nr)
        {
            return colorDistribution.Distribution.OrderByDescending(x => x.Value).Take(nr).Select(x => $"{x.Key.Name} - {x.Value}");
        }


        public HarmonyResult IsComplementary(Bitmap image)
        {
            var colorDistribution = GetColorsDistribution(image);
            var orderedColors = colorDistribution.Distribution.OrderByDescending(x => x.Value).Select(x => x.Key);

            return new HarmonyResult()
            {
                Value = ColorHarmonies.Complementary(orderedColors.ElementAt(0), orderedColors.ElementAt(1)),
                ColorsList = GetMostUsedColors(colorDistribution, 2),
                ImageAsBase64 = colorDistribution.Image.ToBase64String(ImageFormat.Jpeg)    
            };
        }


        public HarmonyResult IsSplitComplementary(Bitmap image)
        {
            var colorDistribution = GetColorsDistribution(image);
            var orderedColors = colorDistribution.Distribution.OrderByDescending(x => x.Value).Select(x => x.Key);

            return new HarmonyResult()
            {
                Value = ColorHarmonies.SplitComplementary(orderedColors.ElementAt(0), orderedColors.ElementAt(1), orderedColors.ElementAt(2)),
                ColorsList = GetMostUsedColors(colorDistribution, 3),
                ImageAsBase64 = colorDistribution.Image.ToBase64String(ImageFormat.Jpeg)
            };
        }


        public HarmonyResult IsAnalogous(Bitmap image)
        {
            var colorDistribution = GetColorsDistribution(image);
            var orderedColors = colorDistribution.Distribution.OrderByDescending(x => x.Value).Select(x => x.Key);

            return new HarmonyResult()
            {
                Value = ColorHarmonies.Analogous(orderedColors.ElementAt(0), orderedColors.ElementAt(1), orderedColors.ElementAt(2)),
                ColorsList = GetMostUsedColors(colorDistribution, 3),
                ImageAsBase64 = colorDistribution.Image.ToBase64String(ImageFormat.Jpeg)
            };
        }

        public HarmonyResult IsTriad(Bitmap image)
        {
            var colorDistribution = GetColorsDistribution(image);
            var orderedColors = colorDistribution.Distribution.OrderByDescending(x => x.Value).Select(x => x.Key);

            return new HarmonyResult()
            {
                Value = ColorHarmonies.Triad(orderedColors.ElementAt(0), orderedColors.ElementAt(1), orderedColors.ElementAt(2)),
                ColorsList = GetMostUsedColors(colorDistribution, 3),
                ImageAsBase64 = colorDistribution.Image.ToBase64String(ImageFormat.Jpeg)
            };
        }


        public HarmonyResult IsHarmonious(Bitmap image)
        {
            var colorDistribution = GetColorsDistribution(image);
            var genericImage = colorDistribution.Image;

            return new HarmonyResult()
            {
                Value = ColorHarmonies.Harmonious(genericImage),
                ColorsList = GetMostUsedColors(colorDistribution, 4),
                HarmonyScore = ColorHarmonies.GetAverageImageScore(genericImage),
                ImageAsBase64 = colorDistribution.Image.ToBase64String(ImageFormat.Jpeg)
            };
        }


        private ColorDistributionResult GetColorsDistribution(Bitmap image)
        {
            var dictionary = Colors.GetColors().ToDictionary(x => x, x => 0);
            for (var i = 0; i < image.Size.Width; i++)
            {
                for (var j = 0; j < image.Size.Height; j++)
                {
                    var pixelColor = image.GetPixel(i, j);
                    if (!Colors.CheckColorIsNotNeutral(pixelColor))
                    {
                        var genericColor = Colors.GetGenericColorOfGivenColor(pixelColor);
                        dictionary[genericColor]++;
                        image.SetPixel(i, j, genericColor.Color);
                    }
                }
            }

            return new ColorDistributionResult() { Distribution = dictionary, Image = image};
        }

    }
}