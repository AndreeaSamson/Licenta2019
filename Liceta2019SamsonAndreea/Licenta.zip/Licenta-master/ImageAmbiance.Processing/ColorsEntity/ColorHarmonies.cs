﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

namespace ImageAmbiance.Processing.ColorsEntity
{
    public class ColorHarmonies
    {
        /// <summary>
        /// Complementary colors (or Direct Complementary) are those that appear opposite each other on the color wheel.
        /// </summary>
        /// <param name="color1"></param>
        /// <param name="color2"></param>
        /// <returns></returns>
        public static bool Complementary(Colors color1, Colors color2)
        {
            var list = new List<Colors>(){color1, color2};
            var sortedList = list.OrderBy(x => x.Index);

            return sortedList.ElementAt(1).Index % 6 == sortedList.ElementAt(0).Index % 6;
        }


        /// <summary>
        /// A split-complementary color arrangement results from one color paired with two colors on either side of the original color’s direct complement creating a scheme containing three colors
        /// </summary>
        /// <param name="colors"></param>
        /// <returns></returns>
        public static bool SplitComplementary(Colors color1, Colors color2, Colors color3)
        {
            var list = new List<Colors>() { color1, color2, color3 };
            var sortedColors = list.OrderBy(x => x.Index);

            return sortedColors.ElementAt(1).Index == sortedColors.ElementAt(0).Index + 5 &&
                   sortedColors.ElementAt(2).Index == sortedColors.ElementAt(0).Index + 7;
        }


        /// <summary>
        /// Analogous harmonies are based on three or more colors that sit side-by-side on the color wheel.
        /// </summary>
        /// <param name="colors"></param>
        /// <returns></returns>
        public static bool Analogous(Colors color1, Colors color2, Colors color3)
        {
            var list = new List<Colors>() { color1, color2, color3 };
            var sortedColors = list.OrderBy(x => x.Index);

            return sortedColors.ElementAt(1).Index == sortedColors.ElementAt(0).Index + 1 && sortedColors.ElementAt(2).Index == sortedColors.ElementAt(0).Index + 2;
        }


        /// <summary>
        /// Triad colors are three colors equally spaced from one another, creating an equilateral triangle on the color wheel.
        /// </summary>
        /// <param name="colors"></param>
        /// <returns></returns>
        public static bool Triad(Colors color1, Colors color2, Colors color3)
        {
            var list = new List<Colors>() { color1, color2, color3 };
            var sortedColors = list.OrderBy(x => x.Index);

            var modC1 = sortedColors.ElementAt(0).Index % 4;
            var modC2 = sortedColors.ElementAt(1).Index % 4;
            var modC3 = sortedColors.ElementAt(2).Index % 4;

            return modC1 == modC2 && modC2 == modC3;
        }



        public static int AddPercentage(Colors color, int sum, Bitmap image, int i, int j)
        {
            var neighbour = image.GetPixel(i, j);
            if (!Colors.CheckColorIsNotNeutral(neighbour))
            {
                var neighbourColor = Colors.GetColors().First(x => x.R == neighbour.R && x.B == neighbour.B && x.G == neighbour.G);
                sum += color.PercentageList.ElementAt(neighbourColor.Index - 1);
            }

            return sum;
        }

        public static float GetAverageImageScore(Bitmap image)
        {
            var pictureScore = 0;

            for (var i = 1; i < image.Size.Width - 1; i++)
            {
                for (var j = 1; j < image.Size.Height - 1; j++)
                {
                    var sum = 0;

                    var pixelColor = image.GetPixel(i, j);
                    if (!Colors.CheckColorIsNotNeutral(pixelColor))
                    {
                        var color = Colors.GetColors().First(x => x.R == pixelColor.R && x.B == pixelColor.B && x.G == pixelColor.G);

                        sum = AddPercentage(color, sum, image, i - 1, j - 1);
                        sum = AddPercentage(color, sum, image, i - 1, j);
                        sum = AddPercentage(color, sum, image, i - 1, j + 1);
                        sum = AddPercentage(color, sum, image, i, j - 1);
                        sum = AddPercentage(color, sum, image, i, j + 1);
                        sum = AddPercentage(color, sum, image, i + 1, j - 1);
                        sum = AddPercentage(color, sum, image, i + 1, j);
                        sum = AddPercentage(color, sum, image, i + 1, j + 1);
                        sum = sum / 8;
                        pictureScore += sum;
                    }
                }
            }

            return (pictureScore / ((image.Size.Width - 2) * (image.Size.Height - 1)));
        }

        public static bool Harmonious(Bitmap image)
        {
            if (GetAverageImageScore(image) > 75)
            {
                return true;
            }

            return false;
        }


    }
}
