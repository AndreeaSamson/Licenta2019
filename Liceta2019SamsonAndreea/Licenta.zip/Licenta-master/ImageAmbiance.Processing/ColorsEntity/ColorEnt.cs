﻿using System;
using System.Collections.Generic;
using System.Drawing;

namespace ImageAmbiance.Processing.ColorsEntity
{
    public class ColorEnt
    {
        //private ColorEnt(string name, int index, int b, int g, int r, Color color)
        //{
        //    Name = name;
        //    Index = index;
        //    B = b;
        //    G = g;
        //    R = r;
        //    Color = color;
        //}

        //public string Name { get; set; }

        //public int Index { get; set; }

        //public int B { get; set; }

        //public int G { get; set; }

        //public int R { get; set; }

        //public Color Color { get; set; }

        //public static ColorEnt Red = new ColorEnt("Red", 1, Color.Red.B, Color.Red.G, Color.Red.R, Color.Red);

        //public static ColorEnt Orange = new ColorEnt("Orange", 2, Color.Orange.B, Color.Orange.G, Color.Orange.R, Color.Orange);

        //public static ColorEnt Yellow = new ColorEnt("Yellow", 3, Color.Yellow.B, Color.Yellow.G, Color.Yellow.R, Color.Yellow);

        //public static ColorEnt SpringGreen = new ColorEnt("SpringGreen", 4, Color.SpringGreen.B, Color.SpringGreen.G, Color.SpringGreen.R, Color.SpringGreen);

        //public static ColorEnt Green = new ColorEnt("Green", 5, Color.Green.B, Color.Green.G, Color.Green.R, Color.Green);

        //public static ColorEnt Turquise = new ColorEnt("Turquise", 6, Color.Turquoise.B, Color.Turquoise.G, Color.Turquoise.R, Color.Turquoise);

        //public static ColorEnt Cyan = new ColorEnt("Cyan", 7, Color.Cyan.B, Color.Cyan.G, Color.Cyan.R, Color.Cyan);

        //public static ColorEnt SkyBlue = new ColorEnt("SkyBlue", 8, Color.SkyBlue.B, Color.SkyBlue.G, Color.SkyBlue.R, Color.SkyBlue);

        //public static ColorEnt Blue = new ColorEnt("Blue", 9, Color.Blue.B, Color.Blue.G, Color.Blue.R, Color.Blue);

        //public static ColorEnt Violet = new ColorEnt("Violet", 10, Color.Violet.B, Color.Violet.G, Color.Violet.R, Color.Violet);

        //public static ColorEnt Magenta = new ColorEnt("Magenta", 11, Color.Magenta.B, Color.Magenta.G, Color.Magenta.R, Color.Magenta);

        //public static ColorEnt HotPink = new ColorEnt("HotPink", 12, Color.HotPink.B, Color.HotPink.G, Color.HotPink.R, Color.HotPink);

        //public static IEnumerable<ColorEnt> GetColors()
        //{
        //    yield return Red;
        //    yield return Orange;
        //    yield return Yellow;
        //    yield return SpringGreen;
        //    yield return Green;
        //    yield return Turquise;
        //    yield return Cyan;
        //    yield return SkyBlue;
        //    yield return Blue;
        //    yield return Violet;
        //    yield return Magenta;
        //    yield return HotPink;
        //    //yield return Black;
        //    //yield return Dimgray;
        //    //yield return Darkgrey;
        //    //yield return Silver;
        //    //yield return White;
        //}

        //public static bool CheckColorIsNotNeutral(Color color)
        //{
        //    //var x = System.Drawing.Color.Black;
        //    //foreach (var neutral in neutralColors)
        //    //{
        //    //    if (neutral.R == color.R && neutral.G == color.G && neutral.B == color.B)
        //    //    {
        //    //        return true;
        //    //    }
        //    //}

        //    //return false;

        //    //if (color == System.Drawing.Color.FromKnownColor(KnownColor.Black))

        //    // Neutral -> White
        //    if (color.R >= 215 && color.G >= 215 && color.B >= 215)
        //    {
        //        return true;
        //    }

        //    // Neutral -> Black
        //    if (color.R <= 10 && color.G <= 10 && color.B <= 10)
        //    {
        //        return true;
        //    }

        //    return false;
        //}


        //public static ColorEnt GetGenericColorOfGivenColor(Color givenColor)
        //{
        //    var smallestDifference = 1000.00;
        //    var mostUsedColor = Red;

        //    foreach (var color in GetColors())
        //    {
        //        var substraction = Math.Abs(color.R- givenColor.R) +
        //                           Math.Abs(color.G - givenColor.G) +
        //                           Math.Abs(color.B - givenColor.B);
        //        if (substraction < smallestDifference)
        //        {

        //            smallestDifference = substraction;
        //            mostUsedColor = color;
        //        }

        //    }

        //    return mostUsedColor;
        //}


    }
}
