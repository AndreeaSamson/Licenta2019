﻿namespace ImageAmbiance.Processing.ColorsEntity
{
    public class Bgr
    {
        public Bgr(int blue, int green, int red)
        {
            Blue = blue;
            Green = green;
            Red = red;
        }

        public int Blue { get; set; }

        public int Green { get; set; }

        public int Red { get; set; }    
    }
}
