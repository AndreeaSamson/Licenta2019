﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

namespace ImageAmbiance.Processing.ColorsEntity
{
    public class Colors
    {
        #region OldVersion
        //private Colors(string name, int index, Bgr lower, Bgr higher, Color color, List<int> percentageList)
        //{
        //    Name = name;
        //    Index = index;
        //    Lower = lower;
        //    Higher = higher;
        //    Color = color;
        //    PercentageList = percentageList;
        //}

        //public string Name { get; set; }

        //public Bgr Lower { get; private set; }

        //public Bgr Higher { get; private set; }

        //public int Index { get; set; }

        //public Color Color { get; set; }

        //public List<int> PercentageList { get; set; }


        //public static Colors Red = new Colors("Red", 1, new Bgr(0, 0, 255), new Bgr(0, 124, 255), Color.Red, HarmonyMatrix.RedHarmonyPercentage);

        //public static Colors Orange = new Colors("Orange", 2, new Bgr(0, 125, 255), new Bgr(0, 254, 255), Color.Orange, HarmonyMatrix.OrangeHarmonyPercentage);

        //public static Colors Yellow = new Colors("Yellow", 3, new Bgr(0, 255, 255), new Bgr(0, 255, 126), Color.Yellow, HarmonyMatrix.YellowHarmonyPercentage);

        //public static Colors SpringGreen = new Colors("SpringGreen", 4, new Bgr(0, 255, 125), new Bgr(0, 255, 1), Color.SpringGreen, HarmonyMatrix.SpringGreenHarmonyPercentage);

        //public static Colors Green = new Colors("Green", 5, new Bgr(0, 255, 0), new Bgr(124, 255, 0), Color.Green, HarmonyMatrix.GreenHarmonyPercentage);

        //public static Colors Turquise = new Colors("Turquise", 6, new Bgr(125, 255, 0), new Bgr(254, 255, 0), Color.Turquoise, HarmonyMatrix.TurquoiseHarmonyPercentage);

        //public static Colors Cyan = new Colors("Cyan", 7, new Bgr(255, 255, 0), new Bgr(255, 126, 0), Color.Cyan, HarmonyMatrix.CyanHarmonyPercentage);

        //public static Colors SkyBlue = new Colors("SkyBlue", 8, new Bgr(255, 125, 0), new Bgr(255, 1, 0), Color.SkyBlue, HarmonyMatrix.SkyBlueHarmonyPercentage);

        //public static Colors Blue = new Colors("Blue", 9, new Bgr(255, 0, 0), new Bgr(255, 0, 124), Color.Blue, HarmonyMatrix.BlueHarmonyPercentage);

        //public static Colors Violet = new Colors("Violet", 10, new Bgr(255, 0, 125), new Bgr(255, 0, 254), Color.Violet, HarmonyMatrix.VioletHarmonyPercentage);

        //public static Colors Magenta = new Colors("Magenta", 11, new Bgr(255, 0, 255), new Bgr(126, 0, 255), Color.Magenta, HarmonyMatrix.MagentaHarmonyPercentage);

        //public static Colors HotPink = new Colors("HotPink", 12, new Bgr(125, 0, 255), new Bgr(0, 0, 254), Color.HotPink, HarmonyMatrix.HotPinkHarmonyPercentage);






        //public static IEnumerable<Colors> GetColors()
        //{
        //    yield return Red;
        //    yield return Orange;
        //    yield return Yellow;
        //    yield return SpringGreen;
        //    yield return Green;
        //    yield return Turquise;
        //    yield return Cyan;
        //    yield return SkyBlue;
        //    yield return Blue;
        //    yield return Violet;
        //    yield return Magenta;
        //    yield return HotPink;
        //}


        //public static bool CheckColorIsNotNeutral(Color color)
        //{
        //    // Neutral -> White
        //    if (color.R >= 215 && color.G >= 215 && color.B >= 215)
        //    {
        //        return true;
        //    }

        //    // Neutral -> Black
        //    if (color.R <= 10 && color.G <= 10 && color.B <= 10)
        //    {
        //        return true;
        //    }

        //    return false;
        //}


        //public static Colors GetGenericColorOfGivenColor(Color givenColor)
        //{
        //    var smallestDifference = 1000.00;
        //    var mostUsedColor = Red;

        //    foreach (var color in GetColors())
        //    {
        //        var substraction = Math.Abs(color.Lower.Red - givenColor.R) +
        //                           Math.Abs(color.Lower.Green - givenColor.G) +
        //                           Math.Abs(color.Lower.Blue - givenColor.B);
        //        if (substraction < smallestDifference)
        //        {

        //            smallestDifference = substraction;
        //            mostUsedColor = color;
        //        }

        //    }

        //    return mostUsedColor;
        //}

        #endregion OldVersion


        #region NewVersion

        private Colors(string name, int index, int b, int g, int r, Color color, List<int> percentageList)
        {
            Name = name;
            Index = index;
            B = b;
            G = g;
            R = r;
            Color = color;
            PercentageList = percentageList;
        }

        public string Name { get; set; }

        public int Index { get; set; }

        public int B { get; set; }

        public int G { get; set; }

        public int R { get; set; }

        public Color Color { get; set; }

        public List<int> PercentageList { get; set; }



        public static Colors Red = new Colors("Red", 1, Color.Red.B, Color.Red.G, Color.Red.R, Color.Red, HarmonyMatrix.RedHarmonyPercentage);

        public static Colors Orange = new Colors("Orange", 2, Color.Orange.B, Color.Orange.G, Color.Orange.R, Color.Orange, HarmonyMatrix.OrangeHarmonyPercentage);

        public static Colors Yellow = new Colors("Yellow", 3, Color.Yellow.B, Color.Yellow.G, Color.Yellow.R, Color.Yellow, HarmonyMatrix.YellowHarmonyPercentage);

        public static Colors SpringGreen = new Colors("SpringGreen", 4, Color.SpringGreen.B, Color.SpringGreen.G, Color.SpringGreen.R, Color.SpringGreen, HarmonyMatrix.SpringGreenHarmonyPercentage);

        public static Colors Green = new Colors("Green", 5, Color.Green.B, Color.Green.G, Color.Green.R, Color.Green, HarmonyMatrix.GreenHarmonyPercentage);

        public static Colors Turquise = new Colors("Turquise", 6, Color.Turquoise.B, Color.Turquoise.G, Color.Turquoise.R, Color.Turquoise, HarmonyMatrix.TurquoiseHarmonyPercentage);

        public static Colors Cyan = new Colors("Cyan", 7, Color.Cyan.B, Color.Cyan.G, Color.Cyan.R, Color.Cyan, HarmonyMatrix.CyanHarmonyPercentage);

        public static Colors SkyBlue = new Colors("SkyBlue", 8, Color.SkyBlue.B, Color.SkyBlue.G, Color.SkyBlue.R, Color.SkyBlue, HarmonyMatrix.SkyBlueHarmonyPercentage);

        public static Colors Blue = new Colors("Blue", 9, Color.Blue.B, Color.Blue.G, Color.Blue.R, Color.Blue, HarmonyMatrix.BlueHarmonyPercentage);

        public static Colors Violet = new Colors("Violet", 10, Color.Violet.B, Color.Violet.G, Color.Violet.R, Color.Violet, HarmonyMatrix.VioletHarmonyPercentage);

        public static Colors Magenta = new Colors("Magenta", 11, Color.Magenta.B, Color.Magenta.G, Color.Magenta.R, Color.Magenta, HarmonyMatrix.MagentaHarmonyPercentage);

        public static Colors HotPink = new Colors("HotPink", 12, Color.HotPink.B, Color.HotPink.G, Color.HotPink.R, Color.HotPink, HarmonyMatrix.HotPinkHarmonyPercentage);

        public static IEnumerable<Colors> GetColors()
        {
            yield return Red;
            yield return Orange;
            yield return Yellow;
            yield return SpringGreen;
            yield return Green;
            yield return Turquise;
            yield return Cyan;
            yield return SkyBlue;
            yield return Blue;
            yield return Violet;
            yield return Magenta;
            yield return HotPink;
        }

        public static bool CheckColorIsNotNeutral(Color color)
        {
            // Neutral -> White
            if (color.R >= 215 && color.G >= 215 && color.B >= 215)
            {
                return true;
            }

            // Neutral -> Black
            if (color.R <= 10 && color.G <= 10 && color.B <= 10)
            {
                return true;
            }

            return false;
        }


        public static Colors GetGenericColorOfGivenColor(Color givenColor)
        {
            var smallestDifference = 1000.00;
            var mostUsedColor = Red;

            foreach (var color in GetColors())
            {
                var substraction = Math.Abs(color.R - givenColor.R) +
                                   Math.Abs(color.G - givenColor.G) +
                                   Math.Abs(color.B - givenColor.B);
                if (substraction < smallestDifference)
                {

                    smallestDifference = substraction;
                    mostUsedColor = color;
                }

            }

            return mostUsedColor;
        }


        #endregion NewVersion


    }
}
