﻿using System.Collections.Generic;

namespace ImageAmbiance.Processing.ColorsEntity
{
    public class HarmonyMatrix
    {
        public static List<int> RedHarmonyPercentage = new List<int>()
        {
            100, // red
            60, // orange
            30, // yellow
            50, // spring green
            20, // green
            60, // turquoise
            75, // cyan
            50, // ocean
            20, // blue
            50, // violet
            30, // magenta
            75 // raspberry
        };

        public static List<int> OrangeHarmonyPercentage = new List<int>()
        {
            60, // red
            100, // orange
            75, // yellow
            30, // spring green
            50, // green
            50, // turquoise
            60, // cyan
            75, // ocean
            30, // blue
            30, // violet
            50, // magenta
            75 // raspberry
        };

        public static List<int> YellowHarmonyPercentage = new List<int>()
        {
            30, // red
            30, // orange
            100, // yellow
            75, // spring green
            50, // green
            60, // turquoise
            40, // cyan
            60, // ocean
            20, // blue
            30, // violet
            30, // magenta
            40 // raspberry
        };

        public static List<int> SpringGreenHarmonyPercentage = new List<int>()
        {
            50, // red
            30, // orange
            75, // yellow
            100, // spring green
            70, // green
            80, // turquoise
            75, // cyan
            60, // ocean
            50, // blue
            50, // violet
            60, // magenta
            50 // raspberry
        };

        public static List<int> GreenHarmonyPercentage = new List<int>()
        {
            20, // red
            50, // orange
            50, // yellow
            70, // spring green
            100, // green
            70, // turquoise
            60, // cyan
            60, // ocean
            40, // blue
            50, // violet
            75, // magenta
            60 // raspberry
        };

        public static List<int> TurquoiseHarmonyPercentage = new List<int>()
        {
            60, // red
            50, // orange
            60, // yellow
            80, // spring green
            75, // green
            100, // turquoise
            70, // cyan
            50, // ocean
            40, // blue
            50, // violet
            40, // magenta
            75 // raspberry
        };

        public static List<int> CyanHarmonyPercentage = new List<int>()
        {
            75, // red
            60, // orange
            40, // yellow
            75, // spring green
            60, // green
            70, // turquoise
            100, // cyan
            70, // ocean
            50, // blue
            40, // violet
            50, // magenta
            60 // raspberry
        };

        public static List<int> SkyBlueHarmonyPercentage = new List<int>()
        {
            50, // red
            75, // orange
            60, // yellow
            60, // spring green
            60, // green
            50, // turquoise
            70, // cyan
            100, // ocean
            70, // blue
            60, // violet
            70, // magenta
            60 // raspberry
        };

        public static List<int> BlueHarmonyPercentage = new List<int>()
        {
            20, // red
            30, // orange
            20, // yellow
            50, // spring green
            40, // green
            40, // turquoise
            50, // cyan
            70, // ocean
            100, // blue
            70, // violet
            60, // magenta
            50 // raspberry
        };

        public static List<int> VioletHarmonyPercentage = new List<int>()
        {
            50, // red
            30, // orange
            30, // yellow
            50, // spring green
            50, // green
            50, // turquoise
            40, // cyan
            60, // ocean
            70, // blue
            100, // violet
            70, // magenta
            60 // raspberry
        };

        public static List<int> MagentaHarmonyPercentage = new List<int>()
        {
            30, // red
            50, // orange
            30, // yellow
            60, // spring green
            75, // green
            40, // turquoise
            50, // cyan
            70, // ocean
            60, // blue
            70, // violet
            100, // magenta
            80 // raspberry
        };

        public static List<int> HotPinkHarmonyPercentage = new List<int>()
        {
            75, // red
            75, // orange
            40, // yellow
            50, // spring green
            60, // green
            75, // turquoise
            60, // cyan
            60, // ocean
            50, // blue
            60, // violet
            80, // magenta
            100 // raspberry
        };


    }
}
