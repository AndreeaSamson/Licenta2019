import { Component } from '@angular/core';
import { HttpClient, HttpRequest, HttpEventType } from '@angular/common/http';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  public subResource = {
    Complementary : 'complementara.',
    SplitComplementary : 'complementara impartita',
    Analogous : 'analogous',
    Triad : 'triad',
    Harmony: 'armonioasa'
  }
  public progress: number;
  public message: string;
  public imagePath;
  public imgURL;
  public imageAsBase64: SafeResourceUrl;
  public responseValue: boolean;
  public isResponse: boolean = false;
  public colors: string[];
  public score: number;
  public showScore: boolean = false;
  public subresource: string = '';
  public isProcessing = false;

  constructor(private http: HttpClient, private readonly sanitizer: DomSanitizer) { }

  preview(files) {
    this.refreshData();
    if (files.length === 0) {
      return;
    }

    var mimeType = files[0].type;
    if (mimeType.match(/image\/*/) == null) {
      this.message = "Only images are supported.";
      return;
    }

    var reader = new FileReader();
    this.imagePath = files;
    reader.readAsDataURL(files[0]);
    reader.onload = (_event) => {
      this.imgURL = reader.result;
    }
  }

  upload(files, subresource) {
    this.refreshData();
    if (files.length === 0) {
      return;
    }
    if (subresource === 'Harmony') {
      this.showScore = true;
    }
    
    var mimeType = files[0].type;
    if (mimeType.match(/image\/*/) == null) {
      this.message = "Only images are supported.";
      return;
    }
    
    this.subresource = this.subResource[subresource];
    this.isProcessing = true;

    var reader = new FileReader();
    this.imagePath = files;
    reader.readAsDataURL(files[0]);
    reader.onload = (_event) => {
      this.imgURL = reader.result;
    }

    const formData = new FormData();

    for (const file of files) {
      formData.append(file.name, file);
    }

    const uploadReq = new HttpRequest('POST', `http://localhost:5000/api/Ambiance/${subresource}`, formData);

    this.http.request(uploadReq).subscribe(event => {
      if (event.type === HttpEventType.Response) {
        const jsonResponse = event.body as any;
        this.imageAsBase64 = this.sanitizer.bypassSecurityTrustResourceUrl('data:image/jpg;base64,'
          + jsonResponse.imageAsBase64);;
        this.responseValue = jsonResponse.value;
        this.colors = jsonResponse.colorsList;
        this.score = jsonResponse.harmonyScore;
        this.isResponse = true;
        this.isProcessing = false;
      }
    });
  }

  private refreshData() {
    this.subresource = '';
    this.showScore = false;
    this.colors = [];
    this.imageAsBase64 = '';
    this.imagePath = '';
    this.isResponse = false;
    this.responseValue = false;
    this.score = 0;
    this.message = '';
  }
}
