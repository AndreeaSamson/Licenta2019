﻿using System.Drawing;
using ImageAmbiance.Processing;
using Microsoft.AspNetCore.Mvc;

namespace ImageAmbiance.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AmbianceController : ControllerBase
    {
        private readonly ImageProcessingService service;

        public AmbianceController(ImageProcessingService service)
        {
            this.service = service;
        }

        [HttpPost("Complementary"), DisableRequestSizeLimit]
        public IActionResult GetResult()
        {
            var file = Request.Form.Files[0];
            using (var fileStream = file.OpenReadStream())
            {
                return Ok(service.IsComplementary(new Bitmap(fileStream)));
            }
        }

        [HttpPost("SplitComplementary"), DisableRequestSizeLimit]
        public IActionResult GetResult2()
        {
            var file = Request.Form.Files[0];
            using (var fileStream = file.OpenReadStream())
            {
                return Ok(service.IsSplitComplementary(new Bitmap(fileStream)));
            }
        }

        [HttpPost("Analogous"), DisableRequestSizeLimit]
        public IActionResult GetResult3()
        {
            var file = Request.Form.Files[0];
            using (var fileStream = file.OpenReadStream())
            {
                return Ok(service.IsAnalogous(new Bitmap(fileStream)));
            }
        }

        [HttpPost("Triad"), DisableRequestSizeLimit]
        public IActionResult GetResult4()
        {
            var file = Request.Form.Files[0];
            using (var fileStream = file.OpenReadStream())
            {
                return Ok(service.IsTriad(new Bitmap(fileStream)));
            }
        }

        [HttpPost("Harmony"), DisableRequestSizeLimit]
        public IActionResult GetResult6()
        {
            var file = Request.Form.Files[0];
            using (var fileStream = file.OpenReadStream())
            {
                return Ok(service.IsHarmonious(new Bitmap(fileStream)));
            }
        }
    }
}
